package Exercicio_Pintinho_Piu;
	import java.util.List;

	public class Cachorro extends Animal {
	    private List<Animal> anteriores;

	public Cachorro(List<Animal> anteriores) {
	     super("cachorro", "auau");
	     this.anteriores = anteriores;

}
	@Override
	public void cantar() {
		System.out.println("Lá em casa tinha um cacchorro");
		System.out.println("Lá em casa tinha um cacchorro");
		System.out.println("E o cachorro auau");

    for (Animal a : anteriores) {
    	if (a instanceof Pintinho) {
    		for (int i = 0; i < 4; i++) {
    			System.out.println("E o pintinho piu");
            
    		}
     }
 }
	}
}

        
    

