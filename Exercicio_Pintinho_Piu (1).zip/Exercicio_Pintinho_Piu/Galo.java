package Exercicio_Pintinho_Piu;
import java.util.List;


public class Galo extends Animal {
    private List<Animal> anteriores;

    public Galo(List<Animal> anteriores) {
        super("galo", "cocoricó");
        this.anteriores = anteriores;
    }

    @Override
    public void cantar() {
        System.out.println("Lá em casa tinha um galo");
        System.out.println("Lá em casa tinha um galo");
        System.out.println("E o galo cocoricó");

        for (Animal a : anteriores) {
            if (a instanceof Pintinho) {
                for (int i = 0; i < 5; i++) {
                    System.out.println("E o pintinho piu");
                }
            }
        }
    }
}
