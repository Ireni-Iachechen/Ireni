package Exercicio_Pintinho_Piu;

import java.util.List;

public class Gato extends Animal {
    private List<Animal> anteriores;

    public Gato(List<Animal> anteriores) {
        super("gato", "miau");
        this.anteriores = anteriores;
    }

    	@Override
    public void cantar() {
    		
        System.out.println("Lá em casa tinha um gato");
        System.out.println("Lá em casa tinha um gato");
        System.out.println("E o gato miau");

       for (Animal a : anteriores) {
       if (a instanceof Pintinho) {
       for (int i = 0; i < 4; i++) {
    	   
            System.out.println("E o pintinho piu");
            
            
                }
            }
        }
    }
}
