package Exercicio_Pintinho_Piu;

import java.util.ArrayList;
import java.util.List;

	public class Principal_Musica {
    public static void main(String[] args) {
        List<Animal> animais = new ArrayList<>();

    
        Animal pintinho = new Pintinho();
        animais.add(pintinho);
        pintinho.cantar();

     
        Animal galo = new Galo(animais);
        animais.add(galo);
        galo.cantar();

        
        Animal galinha = new Galinha(animais);
        animais.add(galinha);
        galinha.cantar();

 
        Animal cachorro = new Cachorro(animais);
        animais.add(cachorro);
        cachorro.cantar();

        Animal gato = new Gato(animais);
        animais.add(gato);
        gato.cantar();
    }
}

