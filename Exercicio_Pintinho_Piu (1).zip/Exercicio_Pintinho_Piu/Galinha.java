package Exercicio_Pintinho_Piu;
	import java.util.List;

	public class Galinha extends Animal {
	private List<Animal> anteriores;

	public Galinha(List<Animal> anteriores) {
	        super("galinha", "có");
	        this.anteriores = anteriores;
	    }
	    @Override
	 public void cantar() {
	        System.out.println("Lá em casa tinha uma galinha");
	        System.out.println("Lá em casa tinha uma galinha");
	        System.out.println("E a galinha có");

	     for (Animal a : anteriores) {
	     if (a instanceof Pintinho) {
	     for (int i = 0; i < 4; i++) {
	         System.out.println("E o pintinho piu");
	    
	         
	        
	       }
	     
	 }
	     }
	     
	    }
}
	
	            
	        

