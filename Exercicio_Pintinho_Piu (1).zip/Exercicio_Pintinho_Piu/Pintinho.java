package Exercicio_Pintinho_Piu;

	public class Pintinho extends Animal {

	    public Pintinho() {
	        super("pintinho", "piu");
	    }

	    @Override
	    public void cantar() {
	        // Parte fixa da música
	        System.out.println("Lá em casa tinha um pintinho");
	        System.out.println("Lá em casa tinha um pintinho");
	        // Parte repetida
	        for (int i = 0; i < 6; i++) {
	            System.out.println("E o pintinho piu");
	        }
	    }
	}


