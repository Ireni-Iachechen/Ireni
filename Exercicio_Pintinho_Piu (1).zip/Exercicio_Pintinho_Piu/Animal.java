package Exercicio_Pintinho_Piu;

	 public class Animal {
	 private String nome;
	 private String som;

	 public Animal(String nome, String som) {
	        this.nome = nome;
	        this.som = som;
	    }

	 public String getNome() {
	       	return nome;
	    }

	 public String getSom() {
	        return som;
	    }

	 public void cantar() {
	        System.out.println("Lá em casa tinha um " + nome);
	        System.out.println("Lá em casa tinha um " + nome);
	        System.out.println("E o " + nome + " " + som);
	    }
	 }




